#!/usr/bin/env node
/**
 * Functional check for the retrieval tool.
 *
 *   node check-tools.mjs             every tool, against the real sources (needs internet)
 *   node check-tools.mjs --offline   network-free: startup, tool registry, API-key handling,
 *                                    and the local-document tools
 *
 * Starts dist/index.js over stdio, the way an MCP client does, calls each tool,
 * and prints one line per tool:
 *   PASS   the tool worked
 *   FAIL   the tool failed (exit status 1)
 *   SKIP   needs a PhilPapers API key, and none is set (PHILPAPERS_API_ID, PHILPAPERS_API_KEY)
 *   LIMIT  PhilPapers answered with a browser check this tool can't complete (known limitation)
 * The local-document and download tools get temporary folders, deleted at the end.
 */
import { chmod, mkdir, mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";

const here = dirname(fileURLToPath(import.meta.url));
const offline = process.argv.includes("--offline");
const hasKey = Boolean(process.env.PHILPAPERS_API_ID?.trim() && process.env.PHILPAPERS_API_KEY?.trim());
const TIMEOUT_MS = 90_000;

const EXPECTED_TOOLS = [
  "fetch_pdf", "fetch_text", "get_archive_text", "get_fulltext", "get_gutenberg_text",
  "get_paper", "get_sep_entry", "get_wikisource_text", "list_recent", "local_doc_info",
  "local_doc_read", "local_doc_search", "research", "search_doab", "search_gutenberg",
  "search_internet_archive", "search_openlibrary", "search_papers", "search_sep",
  "search_wikisource",
];

// Temporary folders for the local-document and download tools (both must be 0700).
const base = await mkdtemp(join(tmpdir(), "philosophy-check-"));
const documents = join(base, "documents");
const downloads = join(base, "downloads");
for (const dir of [documents, downloads]) {
  await mkdir(dir, { mode: 0o700 });
  await chmod(dir, 0o700);
}
const doc = join(documents, "check-notes.md");
await writeFile(
  doc,
  [
    "# Notes on Justice",
    "Justice concerns what people owe one another.",
    "\f",
    "## Second page",
    "Knowledge may require more than justified true belief.",
  ].join("\n"),
  { mode: 0o600 },
);

const iso = (date) => date.toISOString().slice(0, 10);
const today = new Date();
const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
// "BROTNO-9" is the open-access example used in the README.
const state = { paperId: "BROTNO-9", sepEntry: "knowledge-analysis" };
const BROWSER_CHECK = /browser check/i;

// mode: "live" (needs internet), "local" (runs in both modes), "offline" (offline mode only).
const checks = [
  { tool: "search_papers", mode: "live", expect: /id: /,
    args: () => ({ query: "phenomenal consciousness", limit: 3, open_access_only: true }) },
  { tool: "research", mode: "live",
    args: () => ({ query: "phenomenal consciousness", limit: 1, open_access_only: true }) },
  { tool: "get_paper", mode: "live", needsKey: true, args: () => ({ id: state.paperId }) },
  { tool: "list_recent", mode: "live", needsKey: true,
    args: () => ({ from: iso(weekAgo), until: iso(today), limit: 3 }) },
  { tool: "fetch_pdf", mode: "live", limit: BROWSER_CHECK, expect: /Saved PhilArchive PDF/,
    args: () => ({ id: state.paperId }) },
  { tool: "get_fulltext", mode: "live", limit: BROWSER_CHECK,
    args: () => ({ id: state.paperId, max_chars: 1500, offset: 0 }) },
  { tool: "search_gutenberg", mode: "live", args: () => ({ query: "euthyphro", limit: 3 }) },
  { tool: "get_gutenberg_text", mode: "live", expect: /euthyphro/i,
    args: () => ({ book_id: 1642, max_chars: 1500, offset: 0 }) },
  { tool: "search_internet_archive", mode: "live",
    args: () => ({ query: "Anselm Proslogium", limit: 3, mediatype: "texts" }) },
  { tool: "get_archive_text", mode: "live",
    args: () => ({ identifier: "stanselmeproslog00anseuoft", max_chars: 1500, offset: 0 }) },
  { tool: "search_wikisource", mode: "live",
    args: () => ({ query: "On What There Is", lang: "en", limit: 3 }) },
  { tool: "get_wikisource_text", mode: "live",
    args: () => ({ title: "On What There Is", lang: "en", max_chars: 1500, offset: 0 }) },
  { tool: "search_openlibrary", mode: "live",
    args: () => ({ query: "Groundwork of the Metaphysics of Morals", limit: 3 }) },
  { tool: "search_doab", mode: "live", args: () => ({ query: "epistemology", limit: 3 }) },
  { tool: "search_sep", mode: "live", args: () => ({ query: "knowledge", limit: 5 }),
    after: (text) => {
      const slug = text.match(/\(slug: ([a-z0-9-]+)\)/);
      if (slug) state.sepEntry = slug[1];
    } },
  { tool: "get_sep_entry", mode: "live",
    args: () => ({ entry: state.sepEntry, max_chars: 1500, offset: 0 }) },
  { tool: "fetch_text", mode: "live",
    args: () => ({ url: "https://www.gutenberg.org/ebooks/1642", max_chars: 1000, offset: 0 }) },
  { tool: "get_paper", label: "get_paper, no key", mode: "offline", expectError: /free API key/,
    args: () => ({ id: state.paperId }) },
  { tool: "local_doc_info", mode: "local", expect: /Justice/, args: () => ({ path: doc, max_headings: 10 }) },
  { tool: "local_doc_search", mode: "local", expect: /justified true belief/,
    args: () => ({ path: doc, query: "justified true belief", context_chars: 40, max_matches: 5, max_chars: 1000 }) },
  { tool: "local_doc_read", mode: "local", expect: /Second page/,
    args: () => ({ path: doc, page_from: 2, page_to: 2, max_chars: 1000 }) },
];
const selected = checks.filter((check) =>
  offline ? check.mode !== "live" : check.mode !== "offline",
);

const env = {
  ...process.env,
  PHILOSOPHY_DOC_ROOTS: documents,
  PHILPAPERS_DOWNLOAD_DIR: downloads,
  PHILOSOPHY_FETCH_HOSTS: "www.gutenberg.org",
};
if (offline) {
  // The offline run checks the missing-key message, so it must not see a real key.
  delete env.PHILPAPERS_API_ID;
  delete env.PHILPAPERS_API_KEY;
}
const transport = new StdioClientTransport({
  command: process.execPath,
  args: [join(here, "dist", "index.js")],
  cwd: here,
  stderr: "pipe",
  env,
});
let serverLog = "";
transport.stderr?.on("data", (chunk) => {
  serverLog = (serverLog + chunk).slice(-4000);
});
const client = new Client({ name: "check-tools", version: "1.0.0" });

const textOf = (result) =>
  (result.content ?? []).map((item) => (item.type === "text" ? item.text : "")).join("\n").trim();
const firstLine = (text) => (text.split("\n").find((line) => line.trim()) ?? "").trim().slice(0, 90);
const tally = { PASS: 0, FAIL: 0, SKIP: 0, LIMIT: 0 };
const report = (status, name, seconds, detail) => {
  tally[status] += 1;
  console.log(`${status.padEnd(5)}  ${name.padEnd(23)} ${seconds}  ${detail}`);
};

try {
  console.log(`Retrieval tool check (${offline ? "offline" : "live"}), Node ${process.version}`);
  await client.connect(transport);
  const names = (await client.listTools()).tools.map((tool) => tool.name).sort();
  const missing = EXPECTED_TOOLS.filter((name) => !names.includes(name));
  const extra = names.filter((name) => !EXPECTED_TOOLS.includes(name));
  if (missing.length || extra.length) {
    report("FAIL", "tool registry", "     ", `missing [${missing.join(", ")}], unexpected [${extra.join(", ")}]`);
  } else {
    report("PASS", "tool registry", "     ", `all ${EXPECTED_TOOLS.length} tools registered`);
  }

  for (const check of selected) {
    const name = check.label ?? check.tool;
    if (check.needsKey && !hasKey) {
      report("SKIP", name, "     ", "no PhilPapers API key (set PHILPAPERS_API_ID and PHILPAPERS_API_KEY)");
      continue;
    }
    const started = Date.now();
    let status = "PASS";
    let detail = "";
    try {
      const result = await client.callTool(
        { name: check.tool, arguments: check.args() },
        undefined,
        { timeout: TIMEOUT_MS },
      );
      const text = textOf(result);
      detail = firstLine(text);
      if (check.expectError) {
        if (!result.isError || !check.expectError.test(text)) {
          status = "FAIL";
          detail = `expected an error matching ${check.expectError}: ${detail}`;
        }
      } else if (check.limit && check.limit.test(text)) {
        status = "LIMIT";
      } else if (result.isError) {
        status = "FAIL";
      } else if (!text) {
        status = "FAIL";
        detail = "empty answer";
      } else if (check.expect && !check.expect.test(text)) {
        status = "FAIL";
        detail = `unexpected answer: ${detail}`;
      } else {
        check.after?.(text);
      }
    } catch (error) {
      status = "FAIL";
      detail = String(error?.message ?? error).slice(0, 90);
    }
    report(status, name, `${((Date.now() - started) / 1000).toFixed(1).padStart(4)}s`, detail);
  }
} catch (error) {
  report("FAIL", "server startup", "     ", String(error?.message ?? error).slice(0, 90));
  if (serverLog) console.log(`Server output:\n${serverLog}`);
} finally {
  await client.close().catch(() => {});
  await rm(base, { recursive: true, force: true });
}

console.log(
  `\n${tally.PASS} passed, ${tally.FAIL} failed` +
    (tally.SKIP ? `, ${tally.SKIP} skipped (no PhilPapers API key)` : "") +
    (tally.LIMIT ? `, ${tally.LIMIT} limited by PhilPapers' browser check (download those PDFs in a browser)` : "") +
    ".",
);
if (tally.FAIL && !offline) {
  console.log(
    "If every network check failed, check your internet connection or firewall.\n" +
      "A single failure usually means that source is down or has changed; try again later before changing code.",
  );
}
process.exit(tally.FAIL ? 1 : 0);
