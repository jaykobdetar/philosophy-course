#!/usr/bin/env python3
"""Consistency checks for this repository's documents.

1. Every relative Markdown link resolves to an existing file or folder.
2. The unit map (curriculum/map.md) and the files in curriculum/units/ agree,
   and each unit file's title matches its name in the map.
3. The unit names in the learner's status template match the unit map.
4. Every path in the README's "Repository layout" block exists (except entries
   marked "created at setup"), and every top-level item is listed there.

Run from anywhere:  python3 tools/check_docs.py
Exits with status 1 if anything fails. Standard library only.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LINK = re.compile(r"\[([^\]]*)\]\(([^)\s]+)\)")
SKIP_TOP = {".git", "learner"}  # version control, and the private workspace
# Installed dependencies (node_modules) are skipped wherever they appear.
problems = []


def rel(path):
    return path.relative_to(ROOT).as_posix()


def markdown_files():
    for path in sorted(ROOT.rglob("*.md")):
        parts = path.relative_to(ROOT).parts
        if parts[0] not in SKIP_TOP and "node_modules" not in parts:
            yield path


def prose_lines(text):
    """Yield (line number, line) with fenced and inline code removed."""
    fenced = False
    for number, line in enumerate(text.splitlines(), 1):
        if line.lstrip().startswith("```"):
            fenced = not fenced
            continue
        if not fenced:
            yield number, re.sub(r"`[^`]*`", "", line)


def check_links():
    for path in markdown_files():
        for number, line in prose_lines(path.read_text(encoding="utf-8")):
            for _, target in LINK.findall(line):
                if target.startswith("#") or re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", target):
                    continue  # same-page anchor, or a URL
                if not (path.parent / target.split("#", 1)[0]).exists():
                    problems.append(f"{rel(path)}:{number}: broken link to {target}")


def check_units():
    """Return {unit id: name} from the map, checking it against the unit files."""
    listed = {}
    for name, target in LINK.findall((ROOT / "curriculum" / "map.md").read_text(encoding="utf-8")):
        if target.startswith("units/"):
            listed[Path(target).stem] = name
    files = {p.stem for p in (ROOT / "curriculum" / "units").glob("*.md")}
    for unit in sorted(files - set(listed)):
        problems.append(f"curriculum/units/{unit}.md is not listed in curriculum/map.md")
    for unit in sorted(set(listed) - files):
        problems.append(f"curriculum/map.md lists units/{unit}.md, which doesn't exist")
    for unit, name in sorted(listed.items()):
        path = ROOT / "curriculum" / "units" / f"{unit}.md"
        if path.exists():
            title = path.read_text(encoding="utf-8").splitlines()[0].lstrip("#").strip()
            if title != name:
                problems.append(f"{rel(path)}: title '{title}' doesn't match '{name}' in the map")
    return listed


def check_status_template(listed):
    path = ROOT / "templates" / "learner" / "record" / "units.md"
    names = []
    for line in path.read_text(encoding="utf-8").splitlines():
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if line.startswith("|") and cells[0] not in ("Unit", "") and not set(line) <= set("|-: "):
            names.append(cells[0])
    missing = sorted(set(listed.values()) - set(names))
    extra = sorted(set(names) - set(listed.values()))
    if missing or extra:
        problems.append(f"{rel(path)} doesn't match the unit map (missing: {missing}; extra: {extra})")


def check_layout():
    lines = (ROOT / "README.md").read_text(encoding="utf-8").splitlines()
    if "## Repository layout" not in lines:
        problems.append("README.md has no '## Repository layout' section")
        return
    block, inside = [], False
    for line in lines[lines.index("## Repository layout") + 1:]:
        if line.lstrip().startswith("```"):
            if inside:
                break
            inside = True
        elif inside:
            block.append(line)
    stack, top_level = [], set()
    for line in block:
        match = re.match(r"^((?:│   |    )*)(├── |└── )?(\S+)(.*)$", line)
        if not match:
            continue
        indent, branch, name, comment = match.groups()
        depth = len(indent) // 4 + (1 if branch else 0)
        stack = stack[:depth] + [name.rstrip("/")]
        if depth == 0:
            continue  # the repository folder itself
        if depth == 1:
            top_level.add(stack[1])
        if "created at setup" in comment:
            continue
        if not (ROOT.joinpath(*stack[1:])).exists():
            problems.append(f"README.md layout lists {'/'.join(stack[1:])}, which doesn't exist")
    for item in sorted(p.name for p in ROOT.iterdir() if p.name not in SKIP_TOP):
        if item not in top_level:
            problems.append(f"README.md layout doesn't list the top-level item {item}")


def main():
    check_links()
    check_status_template(check_units())
    check_layout()
    if problems:
        print(f"{len(problems)} problem(s) found:")
        for problem in problems:
            print(f"  - {problem}")
        sys.exit(1)
    print("All documentation checks passed.")


if __name__ == "__main__":
    main()
