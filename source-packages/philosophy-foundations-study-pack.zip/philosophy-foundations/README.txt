Extract fully, then open START_HERE.html. All file paths are relative to this folder. Keep the directory tree intact. Private study only; preserve notices.
